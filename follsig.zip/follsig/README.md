# FREE INSTAGRAM FOLLOWERS - WITH TERMUX
<div align="center">
  <img src="Data/Ezlikers.png">
  <br>
  <br>
  <p>
    <img alt="GitHub contributors" src="https://img.shields.io/github/contributors/rozhakxd/Ezlikers">
    <img alt="GitHub issues" src="https://img.shields.io/github/issues/rozhakxd/Ezlikers">
    <img src="https://img.shields.io/badge/PRs-welcome-brightgreen.svg?style=shields">
    <img alt="GitHub pull requests" src="https://img.shields.io/github/issues-pr/rozhakxd/Ezlikers">
    <img alt="GitHub commit activity" src="https://img.shields.io/github/commit-activity/m/rozhakxd/Ezlikers">
    <img alt="Maintenance" src="https://img.shields.io/maintenance/no/2023">
  </p>
  <h4> Get Followers On Instagram Using Termux Only ! </h4>
</div>

##

### What is Ezlikers?
[**Ezlikers**](https://github.com/RozhakXD/Ezlikers) is a script to get lots of followers once submitted. You can get up to 300 followers for one submission. You don't need to do missions to trade followers.

This script was created with the aim of getting lots of followers on an Instagram account and this script was created on the basis of using three free follower provider websites from Turkey.

### Termux command?
First you must have the [Termux](https://f-droid.org/repo/com.termux_118.apk) application to run this script and for how to use it can be seen on [**Youtube**](https://youtu.be/3ZtuiDx3vtI). Then you enter some basic commands below!
```
$ apt update -y && apt upgrade -y
$ pkg install git python-pip
$ git clone https://github.com/RozhakXD/Ezlikers
$ cd "Ezlikers"
$ python -m pip install -r requirements.txt
$ python Run.py
```

```
$ cd "$HOME/Ezlikers" && git pul
$ python Run.py
```

### How long does it take for followers to arrive?
Followers can arrive at your account in about 10 minutes to 30 minutes. The process can be longer or faster depending on how many users use this script.

### Requirements for logging in?

- An Instagram account has a profile photo and one post.
- Use new account or fake account to login.
- After using the script, change the Instagram account password.

### Why does login fail?

- Make sure the Instagram account is logged in and click "IT WAS ME" if it says locked then try again.
- Maybe you entered the wrong username or password.
- You can manually log in on the website **"https://instamoda.org/"** then re-login in Termux.
- You must use airplane mode before logging in.
- Please change your Instagram account if the problem occurs repeatedly.
- Change the password before logging in or if you keep getting the wrong password.

### Lost Instagram account?

- Instagram can block your password so you need to reset the password.
- Change the password after accessing this script to avoid related accounts on the website.
- Don't use the main Instagram account or the original Instagram account.

### Only a few followers arrived?

- Maybe there are no users on the website so only a few followers arrive.
- The target Instagram account already has too many followers from this script.
- The website is under maintenance or not working.
- I hope you run this script during the day so that many users use this website.

### What is recommended?

- You can use multiple sessions to gain followers if you have lots of fake Instagram accounts.
- You have to use a fake account to login in this script.
- After running this script, you are required to change the fake Instagram account password.

### Your Instagram is blocked?

- Maybe because Instagram has detected that your account is a fake or spam account.
- You can use a phone number to sign up for an Instagram account.
- The Instagram account must have a phone number, email and profile photo.

### Follower waiting time?

- If it says you've run out of credit, you can wait 30 minutes to get followers.
- If you run out of credit you can use another new Instagram account.

### Why do followers drop?

- [Why am I seeing a change in the number of likes, follows or comments on Instagram?](https://help.instagram.com/572730176521116/?helpref=search&query=Mengapa%20saya%20melihat%20ada%20perubahan%20jumlah%20suka%2C%20ikuti%2C%20atau%20komentar%20di%20Instagram%3F&search_session_id=&sr=1).
- Instagram followers are detected as spam.
- Accounts that follow you are blocked or deactivated by Instagram.

### Message from the developers?
I as a developer are not responsible if you use a real account to log in and if there are other problems. I just made a script to make it easier to send followers.

##
```python
print("Good luck hope it works!")
```
##
